﻿namespace Pigit.SpriteBuild.Enums
{
    public enum AnimatieTypes
    {
        Idle, Run, Jump, Fall, Attack,
        Dead,
        Hit
    }
}
