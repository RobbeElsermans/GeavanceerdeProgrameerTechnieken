﻿namespace Pigit.SpriteBuild.Enums
{
    enum PigTypes
    {
        Standard = 1
        //Boss
    }
}
