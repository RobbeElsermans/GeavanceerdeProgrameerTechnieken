﻿namespace Pigit.Movement.Enums

{
    enum MoveTypes
    {
        Static = 0,
        Walk,
        GuardTime,
        GuardPosition,
        Follow
    }
}
