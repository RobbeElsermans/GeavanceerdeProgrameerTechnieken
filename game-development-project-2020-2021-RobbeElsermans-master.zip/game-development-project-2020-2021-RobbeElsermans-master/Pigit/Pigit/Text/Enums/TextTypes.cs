﻿namespace Pigit.Text.Enums
{
    enum TextTypes
    {
        Title,
        Normal, 
        Hint, 
        Arrow
    }
}
