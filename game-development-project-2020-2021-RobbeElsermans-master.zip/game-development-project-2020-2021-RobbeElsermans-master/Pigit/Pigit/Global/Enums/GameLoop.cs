﻿namespace Pigit.Global.Enums
{
    public enum GameLoop
    {
        Menu,
        Play,
        Pause,
        Dead,
        End,
        Exit
    }
}
