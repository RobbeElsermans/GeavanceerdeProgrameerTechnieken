﻿namespace Pigit.TileBuild.Enums
{
    enum TileType
    {
        BackGroundTile,
        BorderTile,
        PlatformTile
    }
}
