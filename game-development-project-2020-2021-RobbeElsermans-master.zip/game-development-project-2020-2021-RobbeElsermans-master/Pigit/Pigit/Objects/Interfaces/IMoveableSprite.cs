﻿namespace Pigit.Objects.Interfaces
{
    interface IMoveableSprite
    {
        bool Direction { get; set; }
    }
}
