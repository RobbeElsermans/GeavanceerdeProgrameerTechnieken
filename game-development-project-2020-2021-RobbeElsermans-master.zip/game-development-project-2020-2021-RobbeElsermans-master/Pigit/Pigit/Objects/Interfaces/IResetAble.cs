﻿
namespace Pigit.Objects.Interfaces
{
    interface IResetAble
    {
        public void Reset();
    }
}
