﻿using Microsoft.Xna.Framework;

namespace Pigit.Objects.Interfaces
{
    interface IPosition
    {
        Vector2 Positie { get; set; }
    }
}
