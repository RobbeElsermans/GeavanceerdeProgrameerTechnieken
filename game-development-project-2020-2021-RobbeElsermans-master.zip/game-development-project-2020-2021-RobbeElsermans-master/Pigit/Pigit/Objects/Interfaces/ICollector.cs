﻿namespace Pigit.Objects.Interfaces
{
    interface ICollector
    {
        public int Points { get; set; }
    }
}
