﻿namespace Pigit.Objects.Enums
{
    enum CollectableValues
    {
        BigHeart = 7,
        SmallgHeart = 2,
        BigDiamond = 15,
        SmallgDiamond = 10
    }
}
