﻿namespace Pigit.Objects.Enums
{
    enum CollectableTypes
    {
        BigHeart=1,
        BigDiamond,
        SmallHeart,
        SmallDiamond
    }
}
