﻿namespace Pigit.Music.Interface
{
    interface IEffectMusic
    {
        public void PlayAttack();
        public void StopAttack();
        public void PlayJump();
        public void PlayHit();
        
    }
}
