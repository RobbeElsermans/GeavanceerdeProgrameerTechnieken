﻿namespace Pigit.Music.Interface
{
    interface ICollectMusic
    {
        public void PlayDiamondCollect();
        public void PlayHeartCollect();
    }
}
